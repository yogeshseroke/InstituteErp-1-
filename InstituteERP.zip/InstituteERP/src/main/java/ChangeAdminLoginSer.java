

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.Datahelper;

/**
 * Servlet implementation class ChangeAdminLoginSer
 */
@WebServlet("/ChangeAdminLoginSer")
public class ChangeAdminLoginSer extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ChangeAdminLoginSer() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		PrintWriter out=response.getWriter();
		try
		{
			String uid=request.getParameter("txtuid");
			String pass=request.getParameter("txtpass");
			Datahelper.connection();
			int x=Datahelper.dmlOpe("UPDATE `admin` SET `password`='"+pass+"' WHERE `userid`='"+uid+"'");
			//int x=Datahelper.dmlOpe("INSERT `admin`(`password`,`userid`) VALUE('"+pass+"','"+uid+"')");

			Datahelper.closeConn();
           if(x!=0)
           {
        	   response.sendRedirect("AdminLogin.jsp?q=password change");
           }
           else
           {
        	   response.sendRedirect("AdminLogin.jsp?q=password not change");
           }
		}
		catch(Exception ex)
		{
			out.print(ex.getMessage().toString());
		}


	}

}
